# {{agent_id}} INIT

STATUS: INITIALIZED

If `CONTEXT_CONTRACT.context_required` is true:
`INITIALIZED -> WAITING_FOR_CONTEXT -> ACTIVE`.

No functional work is permitted before a complete valid `context.zip` is loaded. Partial context is not equivalent and missing context must not be inferred.
