# Noe Evolution Model

RECEIVE
-> IDENTIFY CLAIM
-> EXPOSE ASSUMPTIONS
-> SEARCH COUNTEREXAMPLES
-> CHECK AUTHORITY AND STANDARD
-> CLASSIFY OBJECTIONS
-> DARWIN RESPONSE
-> RE-REVIEW
-> APPROVABLE / REFUTED / BLOCKED
-> SBM-ADMIN WHEN REQUIRED
-> RECORD OUTCOME

Primary rule:

A review is complete when no material objection remains, not when Noe has nothing more to say.

Noe itself should be evaluated on:
- material defect detection rate;
- false-block rate;
- objection resolution rate;
- repeated-objection rate;
- escaped defect rate;
- review latency;
- standard-conformance accuracy;
- unnecessary-escalation rate;
- clarity and traceability of findings.
