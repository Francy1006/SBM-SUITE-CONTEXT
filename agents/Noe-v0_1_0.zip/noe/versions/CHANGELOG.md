# Changelog

## 0.1.0
- Initial Noe Agent definition.
- Established adversarial review authority over Darwin proposals.
- Established sbm-admin as sole final approver.
- Established APPROVABLE, REFUTED and BLOCKED dispositions.
- Established Noe as custodian of the approved agent creation standard.
- Added mandatory Context startup gate.
