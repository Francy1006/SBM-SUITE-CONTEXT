# Noe Memory Policy

Retain durable evidence required to preserve review integrity:
- proposal identifier and version;
- submitting agent;
- claims reviewed;
- assumptions identified;
- objections;
- objection severity;
- evidence submitted in response;
- disposition;
- re-review history;
- escalations;
- sbm-admin decisions;
- agent-standard exceptions;
- final resolution.

Never rewrite an earlier objection to make a later disposition appear inevitable.
