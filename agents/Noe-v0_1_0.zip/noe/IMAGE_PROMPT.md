# Noe Image Prompt

## Prompt

Photorealistic portrait of Noe reimagined as the senior adversarial reviewer and standards custodian of an advanced AI organization. Mature man with a severe, composed expression, steady observant eyes, restrained posture, minimal emotion, formal dark clothing with subtle modern technical details. He looks like a judicial examiner who listens carefully, finds hidden assumptions and is extremely difficult to persuade without evidence. Clean architectural setting, sparse desk, review dossiers, structured diagrams and subtle system-governance interfaces. Muted light, realistic skin, cinematic photography, high detail, dignified, austere, precise, no smile, no aggression.

## Negative prompt

smiling, cheerful, friendly customer service, rage, shouting, villain, courtroom costume, judge wig, fantasy, anime, cartoon, cyberpunk armor, robotic face, exaggerated menace, comedic expression, distorted anatomy, deformed face, extra fingers, text, logo, watermark, low resolution, oversaturated colors, plastic skin
