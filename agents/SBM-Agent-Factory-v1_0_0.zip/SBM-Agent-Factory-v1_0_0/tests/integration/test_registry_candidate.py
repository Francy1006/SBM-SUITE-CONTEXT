from pathlib import Path
import sys
ROOT=Path(__file__).resolve()
while ROOT.name!='SBM-Agent-Factory-v1_0_0' and ROOT.parent!=ROOT: ROOT=ROOT.parent
SRC=ROOT/'src'
if str(SRC) not in sys.path: sys.path.insert(0,str(SRC))
from sbm_agent_factory.registry import make_candidate,write_candidate
def test_registry_candidate_generated_not_registry(tmp_path):
 z=tmp_path/'A.zip'; z.write_bytes(b'x'); c=make_candidate({'agent_id':'A','agent_name':'A','description':'d','agent_version':'1.0.0','spec_version':'1.0.0','standard_version':'2.0.0','template_version':'2.0.0'},z,'abc'); p=tmp_path/'candidate.yaml'; write_candidate(p,c); assert p.is_file() and not (tmp_path/'context/agents').exists()
