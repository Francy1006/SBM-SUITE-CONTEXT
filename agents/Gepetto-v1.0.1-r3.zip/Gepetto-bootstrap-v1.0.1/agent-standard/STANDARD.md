# AGENT_CLONING_STANDARD v1.0.0

Physical bootstrap snapshot of the approved SBM agent cloning standard. It normatively separates Agent Definition, Context Contract, Runtime Profile, Approval, Clone Lineage and Execution. Validation is binary VALID/INVALID. sbm-admin is the only approval and escalation authority. NO_LLM_BY_DEFAULT applies to runtime policies.
