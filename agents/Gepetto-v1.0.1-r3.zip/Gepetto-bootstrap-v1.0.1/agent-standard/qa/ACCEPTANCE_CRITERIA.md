# Acceptance Criteria

A candidate agent must validate Definition, Context, Runtime, Approval and Lineage against exact versions; pass deterministic QA; preserve idempotency and traceability; and comply with NO_LLM_BY_DEFAULT.
