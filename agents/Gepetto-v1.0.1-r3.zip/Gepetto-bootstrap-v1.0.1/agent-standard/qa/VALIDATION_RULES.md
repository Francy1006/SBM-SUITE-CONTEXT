# Validation Rules

Binary validation only: VALID or INVALID. Missing, ambiguous, contradictory, unsupported or unauthorized inputs are INVALID. No inference, correction or silent normalization.
