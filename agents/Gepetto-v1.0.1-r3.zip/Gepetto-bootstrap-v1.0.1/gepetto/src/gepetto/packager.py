from pathlib import Path
import zipfile

def package_tree(source, output_zip):
    source=Path(source); out=Path(output_zip); out.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(source.rglob('*')):
            if not p.is_file() or '.pytest_cache' in p.parts or '__pycache__' in p.parts or p.suffix=='.pyc': continue
            info=zipfile.ZipInfo(str(p.relative_to(source))); info.date_time=(1980,1,1,0,0,0); info.compress_type=zipfile.ZIP_DEFLATED; z.writestr(info,p.read_bytes())
    return out
