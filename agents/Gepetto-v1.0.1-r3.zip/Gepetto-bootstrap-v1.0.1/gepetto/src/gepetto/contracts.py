from pathlib import Path
import json
import yaml
from jsonschema import Draft202012Validator

def load_data(path):
    p=Path(path)
    text=p.read_text(encoding='utf-8')
    try: return json.loads(text)
    except json.JSONDecodeError: return yaml.safe_load(text)

def validate_file(data_path,schema_path):
    data=load_data(data_path); schema=load_data(schema_path)
    v=Draft202012Validator(schema)
    return [f"{'/'.join(map(str,e.absolute_path))}: {e.message}" for e in sorted(v.iter_errors(data), key=lambda e:list(e.absolute_path))]
