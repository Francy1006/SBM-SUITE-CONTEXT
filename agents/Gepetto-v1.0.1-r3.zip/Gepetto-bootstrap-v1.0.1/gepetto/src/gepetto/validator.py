from pathlib import Path
from .contracts import load_data, validate_file
FORBIDDEN_PARTS={'.pytest_cache','__pycache__'}

def validate_required_files(agent_root):
    root=Path(agent_root); d=load_data(root/'AGENT_DEFINITION.yaml')
    return [x['path'] for x in d['required_files'] if x['required'] and not (root/x['path']).exists()]

def undeclared_files(agent_root):
    root=Path(agent_root); d=load_data(root/'AGENT_DEFINITION.yaml'); allowed={x['path'] for x in d['required_files']}; extra=[]
    for p in root.rglob('*'):
        if not p.is_file(): continue
        rel=str(p.relative_to(root))
        if any(x in p.parts for x in FORBIDDEN_PARTS) or p.suffix=='.pyc': extra.append(rel); continue
        if rel not in allowed: extra.append(rel)
    return sorted(extra)

def validate_package(agent_root, standard_root=None):
    root=Path(agent_root); standard_root=Path(standard_root) if standard_root else root.parent/'agent-standard'; errors=[]
    for p in validate_required_files(root): errors.append({'code':'MISSING_FIELD','field':'required_files','reason':p})
    for p in undeclared_files(root): errors.append({'code':'UNDECLARED_ARTIFACT','field':'package','reason':p})
    checks=[
      ('AGENT_DEFINITION.yaml',standard_root/'schemas/AGENT_DEFINITION.schema.yaml'),
      ('CONTEXT_CONTRACT.yaml',standard_root/'schemas/CONTEXT_CONTRACT.schema.yaml'),
      ('RUNTIME_PROFILE.yaml',standard_root/'schemas/RUNTIME_PROFILE.schema.yaml'),
      ('CLONE_LINEAGE.yaml',standard_root/'schemas/CLONE_LINEAGE.schema.yaml'),
      ('bootstrap/STANDARD_APPROVAL.yaml',standard_root/'schemas/STANDARD_APPROVAL.schema.yaml'),
      ('runtime/BOOTSTRAP_RUNTIME.yaml',root/'runtime/BOOTSTRAP_RUNTIME.schema.yaml'),
      ('DEPLOYMENT_PROFILE.yaml',root/'schemas/DEPLOYMENT_PROFILE.schema.yaml'),
      ('contracts/gepetto-tests.yaml',root/'schemas/TEST_GENERATION_CONTRACT.schema.yaml'),
      ('contracts/gepetto-validation.yaml',root/'schemas/VALIDATION_SCRIPT_CONTRACT.schema.yaml'),
    ]
    for data,schema in checks:
        if not Path(schema).is_file(): errors.append({'code':'DEPENDENCY_MISSING','field':str(schema),'reason':'schema missing'}); continue
        for e in validate_file(root/data,schema): errors.append({'code':'SCHEMA_VIOLATION','field':data,'reason':e})
    if errors: return errors
    d=load_data(root/'AGENT_DEFINITION.yaml'); cc=load_data(root/'CONTEXT_CONTRACT.yaml'); rp=load_data(root/'RUNTIME_PROFILE.yaml'); cl=load_data(root/'CLONE_LINEAGE.yaml'); dp=load_data(root/'DEPLOYMENT_PROFILE.yaml'); rt=load_data(root/'runtime/BOOTSTRAP_RUNTIME.yaml')
    cross=[(d['context_contract_id'],cc['context_contract_id'],'context_contract_id'),(d['context_contract_version'],cc['context_contract_version'],'context_contract_version'),(d['runtime_profile_id'],rp['runtime_profile_id'],'runtime_profile_id'),(d['runtime_profile_version'],rp['runtime_profile_version'],'runtime_profile_version'),(d['clone_lineage_id'],cl['clone_lineage_id'],'clone_lineage_id'),(d['spec_id'],dp['spec_id'],'deployment.spec_id'),(d['spec_version'],dp['spec_version'],'deployment.spec_version'),(rp['runtime_reference']['runtime_id'],rt['runtime_id'],'runtime_id'),(rp['runtime_reference']['runtime_version'],rt['runtime_version'],'runtime_version')]
    for a,b,f in cross:
        if a!=b: errors.append({'code':'CONTRADICTION','field':f,'reason':f'{a!r}!={b!r}'})
    return errors
