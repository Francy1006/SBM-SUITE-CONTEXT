from pathlib import Path
import hashlib
import json


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()


def manifest(root):
    root = Path(root)
    return [
        {'path': str(p.relative_to(root)), 'sha256': sha256(p)}
        for p in sorted(root.rglob('*'))
        if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts and p.suffix != '.pyc'
    ]


def verify_manifest(root, expected_manifest):
    root = Path(root)
    expected = {item['path']: item['sha256'] for item in expected_manifest}
    actual = {item['path']: item['sha256'] for item in manifest(root)}
    errors = []
    for path, expected_hash in expected.items():
        if path not in actual:
            errors.append({'code': 'CHECKSUM_MISMATCH', 'path': path, 'reason': 'missing artifact'})
        elif actual[path] != expected_hash:
            errors.append({'code': 'CHECKSUM_MISMATCH', 'path': path, 'reason': 'sha256 mismatch'})
    for path in sorted(set(actual) - set(expected)):
        errors.append({'code': 'CHECKSUM_MISMATCH', 'path': path, 'reason': 'unexpected artifact'})
    return errors


def write_trace(path, obj):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n', encoding='utf-8')
