from pathlib import Path
import json, shutil, hashlib
from .contracts import load_data, validate_file
from .resolver import resolve_and_validate, Blocked
from .generator import generate_declared_tests, generate_validation_plan
from .trace import manifest, write_trace

def _safe_rel(v):
    p=Path(v)
    if p.is_absolute() or '..' in p.parts: raise Blocked(f'unsafe path: {v}')
    return p

def _fingerprint(req):
    fields=[req['idempotency_key'],req['spec_id'],req['spec_version'],req['authorization_mode'],req['operation']]
    return hashlib.sha256('|'.join(fields).encode()).hexdigest()

def materialize(request_path, schema_path, bundle_root, source_root, state_root):
    req=load_data(request_path); errs=validate_file(request_path,schema_path)
    if errs: raise Blocked(json.dumps(errs,sort_keys=True))
    resolved=resolve_and_validate(req,bundle_root,Path(bundle_root)/'schemas')
    state=Path(state_root); state.mkdir(parents=True,exist_ok=True); key=req['idempotency_key']; idx=state/'idempotency'/f'{key}.json'; fp=_fingerprint(req)
    if idx.exists():
        old=json.loads(idx.read_text())
        if old['fingerprint']!=fp: raise Blocked('IDEMPOTENCY_CONFLICT')
        return old['result']
    output=Path(req['output_target']).resolve()
    if output.exists() and any(output.iterdir()): raise Blocked('OUTPUT_COLLISION')
    # no output is created until all references are validated above
    output.mkdir(parents=True,exist_ok=True)
    srcroot=Path(source_root).resolve()
    for a in req['artifacts']:
        src=(srcroot/_safe_rel(a['source_path'])).resolve()
        if srcroot not in src.parents and src!=srcroot: raise Blocked('source outside source_root')
        if not src.is_file(): raise Blocked('missing source artifact')
        dst=output/_safe_rel(a['path']); dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
    qaout=output/'_generated_qa'
    generate_declared_tests(resolved['test_contract'],resolved['test_template'],qaout/'tests')
    generate_validation_plan(resolved['validation_contract'],resolved['script_template'],qaout/'validation-scripts')
    trace=state/'traces'/f"{req['execution_id']}.json"
    result={'execution_id':req['execution_id'],'request_id':req['request_id'],'spec_id':req['spec_id'],'spec_version':req['spec_version'],'execution_status':'SUCCEEDED','artifact_manifest':manifest(output),'validation_result':'VALID','test_result':'PASSED','trace_reference':str(trace),'output_reference':str(output)}
    write_trace(trace,{'request':req,'result':result,'additional_llm_calls_by_agent':0,'manual_authorization':'SBM_ADMIN_MANUAL_ZIP_DELIVERY'})
    idx.parent.mkdir(parents=True,exist_ok=True); idx.write_text(json.dumps({'fingerprint':fp,'result':result},indent=2,sort_keys=True)+"\n")
    return result
