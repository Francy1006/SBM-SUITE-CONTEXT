from pathlib import Path
from .resolver import Blocked

def generate_declared_tests(contract, template, out_dir):
    files=template.get('files',{}); out=Path(out_dir); out.mkdir(parents=True,exist_ok=True); generated=[]
    for case in contract['test_cases']:
        tid=case['assertion_contract']
        if tid not in files: raise Blocked('test assertion not defined by exact template')
        entry=files[tid]; p=out/entry['filename']; p.write_text(entry['content'],encoding='utf-8'); generated.append(p)
    return generated

def generate_validation_plan(contract, template, out_dir):
    files=template.get('files',{}); out=Path(out_dir); out.mkdir(parents=True,exist_ok=True); generated=[]
    for step in contract['validation_steps']:
        op=step['operation']
        if op not in files: raise Blocked('validation operation not defined by exact template')
        entry=files[op]; p=out/entry['filename']; p.write_text(entry['content'],encoding='utf-8'); p.chmod(0o755); generated.append(p)
    return generated
