import argparse, json
from .validator import validate_package

def main():
    p=argparse.ArgumentParser(); p.add_argument('agent_root'); a=p.parse_args(); e=validate_package(a.agent_root); print(json.dumps({'status':'VALID' if not e else 'INVALID','errors':e},indent=2)); raise SystemExit(0 if not e else 1)

if __name__ == '__main__':
    main()
