VALID={'PENDING':{'RUNNING','BLOCKED'},'RUNNING':{'SUCCEEDED','FAILED','BLOCKED'},'SUCCEEDED':set(),'FAILED':set(),'BLOCKED':set()}
class InvalidStateTransition(Exception): pass

def transition(job,new_status):
    cur=job['execution_status']
    if new_status not in VALID[cur]: raise InvalidStateTransition(f'{cur}->{new_status}')
    job=dict(job); job['execution_status']=new_status
    if new_status in ('SUCCEEDED','FAILED','BLOCKED') and new_status!='SUCCEEDED' and 'output_reference' not in job: job['output_reference']=None
    return job

def retry(job, attempt_status):
    if job['execution_status']!='RUNNING': raise InvalidStateTransition('retry requires RUNNING')
    max_attempts=3
    if attempt_status!='FAILED_RETRYABLE': raise InvalidStateTransition('not retryable')
    if job['retry_count']>=max_attempts-1: return transition(job,'FAILED')
    job=dict(job); job['retry_count']+=1; job.setdefault('attempts',[]).append({'attempt_number':job['retry_count']+1,'attempt_status':'FAILED_RETRYABLE'}); return job
