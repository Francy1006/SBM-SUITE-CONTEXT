from pathlib import Path
from .contracts import load_data, validate_file
class Blocked(Exception): pass

def exact_path(base, rel):
    base=Path(base).resolve(); p=(base/rel).resolve()
    if p!=base and base not in p.parents: raise Blocked(f'path outside bundle: {rel}')
    if not p.is_file(): raise Blocked(f'missing reference: {rel}')
    return p

def expect(obj, field, value):
    if obj.get(field)!=value: raise Blocked(f'reference mismatch {field}: expected {value!r}, got {obj.get(field)!r}')

def _schema(resolved, data_key, schema_key):
    errs=validate_file(resolved[data_key],resolved[schema_key])
    if errs: raise Blocked(f'{data_key} schema invalid: {errs}')

def resolve_and_validate(request, bundle_root, schemas_root=None):
    refs=request['references']; resolved={k:exact_path(bundle_root,v) for k,v in refs.items()}
    for d,s in [('agent_definition','agent_definition_schema'),('context_contract','context_contract_schema'),('runtime_profile','runtime_profile_schema'),('clone_lineage','clone_lineage_schema'),('deployment_profile','deployment_profile_schema'),('standard_approval','standard_approval_schema'),('test_contract','test_contract_schema'),('validation_contract','validation_contract_schema'),('runtime','runtime_schema')]: _schema(resolved,d,s)
    ad=load_data(resolved['agent_definition']); cc=load_data(resolved['context_contract']); rp=load_data(resolved['runtime_profile']); cl=load_data(resolved['clone_lineage']); dp=load_data(resolved['deployment_profile'])
    expect(ad,'spec_id',request['spec_id']); expect(ad,'spec_version',request['spec_version']); expect(ad,'context_contract_id',request['context_contract_id']); expect(ad,'context_contract_version',request['context_contract_version']); expect(ad,'runtime_profile_id',request['runtime_profile_id']); expect(ad,'runtime_profile_version',request['runtime_profile_version'])
    expect(cc,'context_contract_id',request['context_contract_id']); expect(cc,'context_contract_version',request['context_contract_version']); expect(rp,'runtime_profile_id',request['runtime_profile_id']); expect(rp,'runtime_profile_version',request['runtime_profile_version'])
    if cl.get('agent_id')!=ad.get('agent_id'): raise Blocked('clone lineage agent mismatch')
    expect(dp,'spec_id',request['spec_id']); expect(dp,'spec_version',request['spec_version']); expect(dp,'deployment_type','CHATGPT_CUSTOM_GPT')
    sa=load_data(resolved['standard_approval']); expect(sa,'standard_id',request['standard_id']); expect(sa,'standard_version',request['standard_version']); expect(sa,'approved_by','sbm-admin'); expect(sa,'approval_status','APPROVED')
    tc=load_data(resolved['test_contract']); expect(tc,'test_contract_id',request['test_contract_id']); expect(tc,'test_contract_version',request['test_contract_version']); expect(tc,'test_template_id',request['test_template_id']); expect(tc,'test_template_version',request['test_template_version'])
    vc=load_data(resolved['validation_contract']); expect(vc,'validation_contract_id',request['validation_contract_id']); expect(vc,'validation_contract_version',request['validation_contract_version']); expect(vc,'script_template_id',request['script_template_id']); expect(vc,'script_template_version',request['script_template_version'])
    tt=load_data(resolved['test_template']); expect(tt,'test_template_id',request['test_template_id']); expect(tt,'test_template_version',request['test_template_version'])
    st=load_data(resolved['script_template']); expect(st,'script_template_id',request['script_template_id']); expect(st,'script_template_version',request['script_template_version'])
    rt=load_data(resolved['runtime']); expect(rt,'runtime_id',rp['runtime_reference']['runtime_id']); expect(rt,'runtime_version',rp['runtime_reference']['runtime_version'])
    if request.get('authorization_mode')!='SBM_ADMIN_MANUAL_ZIP_DELIVERY': raise Blocked('manual authorization mode invalid')
    return {'agent_definition':ad,'context_contract':cc,'runtime_profile':rp,'clone_lineage':cl,'deployment_profile':dp,'test_contract':tc,'validation_contract':vc,'test_template':tt,'script_template':st,'runtime':rt,'paths':resolved}
