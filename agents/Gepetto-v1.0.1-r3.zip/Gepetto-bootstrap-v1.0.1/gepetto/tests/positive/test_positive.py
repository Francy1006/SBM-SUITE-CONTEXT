from pathlib import Path
import json

from gepetto.validator import validate_package
from gepetto.contracts import load_data, validate_file
from gepetto.generator import generate_declared_tests, generate_validation_plan
from gepetto.async_job import transition
from gepetto.materializer import materialize

from conftest import agent_root as root, bundle_root as bundle, valid_request


def test_QA_P01_real_end_to_end_materialization(tmp_path):
    req, req_path, output, state, source = valid_request(tmp_path, key='qa-p01')
    result = materialize(
        req_path,
        root() / 'schemas/MATERIALIZATION_REQUEST.schema.yaml',
        bundle(),
        source,
        state,
    )
    assert result['execution_status'] == 'SUCCEEDED'
    result_path = tmp_path / 'result.json'
    result_path.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    assert validate_file(result_path, root() / 'schemas/MATERIALIZATION_RESULT.schema.yaml') == []
    assert (output / 'HELLO.txt').is_file()
    manifest_paths = {item['path'] for item in result['artifact_manifest']}
    assert 'HELLO.txt' in manifest_paths
    assert any(path.startswith('_generated_qa/tests/') for path in manifest_paths)
    assert any(path.startswith('_generated_qa/validation-scripts/') for path in manifest_paths)


def test_QA_P02_manual_authorization_declared():
    assert load_data(root() / 'RUNTIME_PROFILE.yaml')['context_delivery']['MANUAL_CHAT']['authorization'] == 'SBM_ADMIN_MANUAL_ZIP_DELIVERY'


def test_QA_P03_required_files_present():
    assert validate_package(root(), bundle() / 'agent-standard') == []


def test_QA_P04_contracts_validate():
    assert not [e for e in validate_package(root(), bundle() / 'agent-standard') if e['code'] == 'SCHEMA_VIOLATION']


def test_QA_P05_traceability_reconstructs_full_execution(tmp_path):
    req, req_path, output, state, source = valid_request(tmp_path, key='qa-p05')
    result = materialize(
        req_path,
        root() / 'schemas/MATERIALIZATION_REQUEST.schema.yaml',
        bundle(),
        source,
        state,
    )
    trace_path = Path(result['trace_reference'])
    trace = json.loads(trace_path.read_text(encoding='utf-8'))
    traced_request = trace['request']
    traced_result = trace['result']

    assert (traced_request['spec_id'], traced_request['spec_version']) == ('gepetto-agent-spec', '1.0.1')
    assert (traced_request['context_contract_id'], traced_request['context_contract_version']) == ('gepetto-context', '1.0.0')
    assert (traced_request['runtime_profile_id'], traced_request['runtime_profile_version']) == ('gepetto-runtime', '1.0.1')
    deployment = load_data(bundle() / traced_request['references']['deployment_profile'])
    assert (deployment['deployment_id'], deployment['deployment_version']) == ('gepetto-chatgpt-business-v1', '1.0.0')
    assert trace['manual_authorization'] == 'SBM_ADMIN_MANUAL_ZIP_DELIVERY'
    assert traced_result['execution_id'] == req['execution_id']
    assert traced_result['artifact_manifest'] == result['artifact_manifest']
    assert all(item['sha256'] for item in result['artifact_manifest'])
    assert traced_result['test_result'] == 'PASSED'
    assert traced_result['validation_result'] == 'VALID'
    assert traced_result['execution_status'] == 'SUCCEEDED'


def test_QA_P06_zero_additional_llm_calls():
    assert load_data(root() / 'RUNTIME_PROFILE.yaml')['cost_control_policy']['max_llm_calls_per_execution'] == 0


def test_QA_P07_deterministic_generation_and_async_job(tmp_path):
    tc = load_data(root() / 'contracts/gepetto-tests.yaml')
    tt = load_data(root() / 'templates/test-template.yaml')
    vc = load_data(root() / 'contracts/gepetto-validation.yaml')
    st = load_data(root() / 'templates/validation-script-template.yaml')
    tests = generate_declared_tests(tc, tt, tmp_path / 'tests')
    scripts = generate_validation_plan(vc, st, tmp_path / 'scripts')
    assert len(tests) == 22 and len(scripts) == 2
    job = {'execution_status': 'PENDING', 'retry_count': 0, 'attempts': [], 'output_reference': None}
    assert transition(job, 'RUNNING')['execution_status'] == 'RUNNING'
