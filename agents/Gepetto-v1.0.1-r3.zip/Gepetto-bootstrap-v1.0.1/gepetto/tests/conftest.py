from pathlib import Path
import json
import sys

sys.path.insert(0, str(Path(__file__).parents[1] / 'src'))


def agent_root():
    return Path(__file__).parents[1]


def bundle_root():
    return agent_root().parent


def reference_map():
    return {
        'agent_definition': 'gepetto/AGENT_DEFINITION.yaml',
        'agent_definition_schema': 'agent-standard/schemas/AGENT_DEFINITION.schema.yaml',
        'context_contract': 'gepetto/CONTEXT_CONTRACT.yaml',
        'context_contract_schema': 'agent-standard/schemas/CONTEXT_CONTRACT.schema.yaml',
        'runtime_profile': 'gepetto/RUNTIME_PROFILE.yaml',
        'runtime_profile_schema': 'agent-standard/schemas/RUNTIME_PROFILE.schema.yaml',
        'clone_lineage': 'gepetto/CLONE_LINEAGE.yaml',
        'clone_lineage_schema': 'agent-standard/schemas/CLONE_LINEAGE.schema.yaml',
        'deployment_profile': 'gepetto/DEPLOYMENT_PROFILE.yaml',
        'deployment_profile_schema': 'gepetto/schemas/DEPLOYMENT_PROFILE.schema.yaml',
        'standard_approval': 'gepetto/bootstrap/STANDARD_APPROVAL.yaml',
        'standard_approval_schema': 'agent-standard/schemas/STANDARD_APPROVAL.schema.yaml',
        'test_contract': 'gepetto/contracts/gepetto-tests.yaml',
        'test_contract_schema': 'gepetto/schemas/TEST_GENERATION_CONTRACT.schema.yaml',
        'validation_contract': 'gepetto/contracts/gepetto-validation.yaml',
        'validation_contract_schema': 'gepetto/schemas/VALIDATION_SCRIPT_CONTRACT.schema.yaml',
        'test_template': 'gepetto/templates/test-template.yaml',
        'script_template': 'gepetto/templates/validation-script-template.yaml',
        'runtime': 'gepetto/runtime/BOOTSTRAP_RUNTIME.yaml',
        'runtime_schema': 'gepetto/runtime/BOOTSTRAP_RUNTIME.schema.yaml',
    }


def valid_request(tmp_path, *, key='qa-key', operation='materialize-agent'):
    output = tmp_path / 'output'
    state = tmp_path / 'state'
    source = tmp_path / 'source'
    source.mkdir(parents=True, exist_ok=True)
    (source / 'HELLO.txt').write_text('hello from deterministic source\n', encoding='utf-8')
    request = {
        'request_id': 'qa-request',
        'execution_id': 'qa-execution',
        'idempotency_key': key,
        'operation': operation,
        'standard_id': 'AGENT_CLONING_STANDARD',
        'standard_version': '1.0.0',
        'spec_id': 'gepetto-agent-spec',
        'spec_version': '1.0.1',
        'context_contract_id': 'gepetto-context',
        'context_contract_version': '1.0.0',
        'runtime_profile_id': 'gepetto-runtime',
        'runtime_profile_version': '1.0.1',
        'authorization_mode': 'SBM_ADMIN_MANUAL_ZIP_DELIVERY',
        'source': {'source_type': 'MANUAL_ZIP', 'source_id': 'qa-source', 'source_version': '1.0.0'},
        'output_target': str(output),
        'test_contract_id': 'gepetto-tests',
        'test_contract_version': '1.0.0',
        'validation_contract_id': 'gepetto-validation',
        'validation_contract_version': '1.0.0',
        'test_template_id': 'pytest-closed-template',
        'test_template_version': '1.0.0',
        'script_template_id': 'python-validation-template',
        'script_template_version': '1.0.0',
        'references': reference_map(),
        'artifacts': [{'path': 'HELLO.txt', 'source_path': 'HELLO.txt'}],
    }
    request_path = tmp_path / 'request.json'
    request_path.write_text(json.dumps(request, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    return request, request_path, output, state, source
