from pathlib import Path
import copy
import json
import shutil
import pytest

from gepetto.resolver import resolve_and_validate, Blocked
from gepetto.materializer import materialize
from gepetto.async_job import transition, InvalidStateTransition
from gepetto.validator import undeclared_files
from gepetto.trace import verify_manifest

from conftest import agent_root, bundle_root, reference_map, valid_request


def base_req():
    return {
        'standard_id': 'AGENT_CLONING_STANDARD',
        'standard_version': '1.0.0',
        'spec_id': 'gepetto-agent-spec',
        'spec_version': '1.0.1',
        'context_contract_id': 'gepetto-context',
        'context_contract_version': '1.0.0',
        'runtime_profile_id': 'gepetto-runtime',
        'runtime_profile_version': '1.0.1',
        'authorization_mode': 'SBM_ADMIN_MANUAL_ZIP_DELIVERY',
        'test_contract_id': 'gepetto-tests',
        'test_contract_version': '1.0.0',
        'validation_contract_id': 'gepetto-validation',
        'validation_contract_version': '1.0.0',
        'test_template_id': 'pytest-closed-template',
        'test_template_version': '1.0.0',
        'script_template_id': 'python-validation-template',
        'script_template_version': '1.0.0',
        'references': reference_map(),
    }


def expect_block(mod):
    r = base_req()
    r.update(mod)
    with pytest.raises(Blocked):
        resolve_and_validate(r, bundle_root())


def test_QA_N01_missing_field_real_materialization_blocks_without_output(tmp_path):
    req, req_path, output, state, source = valid_request(tmp_path, key='qa-n01')
    del req['spec_id']
    req_path.write_text(json.dumps(req, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    with pytest.raises(Blocked):
        materialize(req_path, agent_root() / 'schemas/MATERIALIZATION_REQUEST.schema.yaml', bundle_root(), source, state)
    assert not output.exists()


def test_QA_N02_missing_standard_approval():
    r = base_req()
    r['references']['standard_approval'] = 'missing.yaml'
    with pytest.raises(Blocked):
        resolve_and_validate(r, bundle_root())


def test_QA_N03_invalid_manual_authority():
    expect_block({'authorization_mode': 'SOMEONE_ELSE'})


def test_QA_N04_wrong_spec_reference():
    expect_block({'spec_version': '9.9.9'})


def test_QA_N05_context_mismatch():
    expect_block({'context_contract_version': '9.9.9'})


def test_QA_N06_runtime_mismatch():
    expect_block({'runtime_profile_version': '9.9.9'})


def test_QA_N07_standard_version_mismatch():
    expect_block({'standard_version': '9.9.9'})


def test_QA_N08_ambiguity_blocked_by_closed_enum():
    expect_block({'authorization_mode': 'sbm-admin OR service'})


def test_QA_N09_contradiction():
    expect_block({'spec_id': 'other'})


def test_QA_N10_idempotency_conflict_real_execution(tmp_path):
    req1, req_path1, output1, state, source = valid_request(tmp_path / 'first', key='qa-n10', operation='materialize-agent')
    first = materialize(req_path1, agent_root() / 'schemas/MATERIALIZATION_REQUEST.schema.yaml', bundle_root(), source, state)
    assert first['execution_status'] == 'SUCCEEDED'

    second_dir = tmp_path / 'second'
    req2, req_path2, output2, _state2, source2 = valid_request(second_dir, key='qa-n10', operation='package-agent')
    req2['execution_id'] = 'qa-execution-second'
    req2['request_id'] = 'qa-request-second'
    req_path2.write_text(json.dumps(req2, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    with pytest.raises(Blocked, match='IDEMPOTENCY_CONFLICT'):
        materialize(req_path2, agent_root() / 'schemas/MATERIALIZATION_REQUEST.schema.yaml', bundle_root(), source2, state)
    assert not output2.exists()


def test_QA_N11_undeclared_artifact_detected(tmp_path):
    dst = tmp_path / 'g'
    shutil.copytree(agent_root(), dst)
    (dst / 'EXTRA.txt').write_text('x', encoding='utf-8')
    assert 'EXTRA.txt' in undeclared_files(dst)


def test_QA_N12_missing_required_file_detected(tmp_path):
    from gepetto.validator import validate_package
    top = tmp_path / 'bundle'
    shutil.copytree(bundle_root(), top)
    (top / 'gepetto/README.md').unlink()
    assert validate_package(top / 'gepetto', top / 'agent-standard')


def test_QA_N13_checksum_mismatch_is_detected(tmp_path):
    req, req_path, output, state, source = valid_request(tmp_path, key='qa-n13')
    result = materialize(req_path, agent_root() / 'schemas/MATERIALIZATION_REQUEST.schema.yaml', bundle_root(), source, state)
    assert verify_manifest(output, result['artifact_manifest']) == []
    (output / 'HELLO.txt').write_text('tampered\n', encoding='utf-8')
    mismatches = verify_manifest(output, result['artifact_manifest'])
    assert any(item['code'] == 'CHECKSUM_MISMATCH' and item['path'] == 'HELLO.txt' for item in mismatches)


def test_QA_N14_llm_call_policy_zero():
    from gepetto.contracts import load_data
    assert load_data(agent_root() / 'RUNTIME_PROFILE.yaml')['cost_control_policy']['max_llm_calls_per_execution'] == 0


def test_QA_N15_invalid_state_transition():
    with pytest.raises(InvalidStateTransition):
        transition({'execution_status': 'FAILED', 'retry_count': 0, 'attempts': [], 'output_reference': None}, 'RUNNING')
