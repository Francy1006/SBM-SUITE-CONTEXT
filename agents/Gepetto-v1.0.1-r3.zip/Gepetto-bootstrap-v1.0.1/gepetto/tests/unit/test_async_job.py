import pytest
from gepetto.async_job import transition, InvalidStateTransition

def job(s='PENDING'): return {'execution_status':s,'retry_count':0,'attempts':[],'output_reference':None}
def test_valid_transition(): assert transition(job(),'RUNNING')['execution_status']=='RUNNING'
def test_invalid_transition():
    with pytest.raises(InvalidStateTransition): transition(job('SUCCEEDED'),'RUNNING')
