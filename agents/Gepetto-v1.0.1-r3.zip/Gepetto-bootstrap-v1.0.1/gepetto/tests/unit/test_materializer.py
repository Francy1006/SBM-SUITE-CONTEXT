from pathlib import Path
import json
import pytest
from gepetto.materializer import materialize
from gepetto.resolver import Blocked

def agent_root(): return Path(__file__).parents[2]
def bundle_root(): return agent_root().parent

def request(tmp_path, spec='gepetto-agent-spec', idem='k'):
    refs={
      'agent_definition':'gepetto/AGENT_DEFINITION.yaml','agent_definition_schema':'agent-standard/schemas/AGENT_DEFINITION.schema.yaml','context_contract':'gepetto/CONTEXT_CONTRACT.yaml','context_contract_schema':'agent-standard/schemas/CONTEXT_CONTRACT.schema.yaml','runtime_profile':'gepetto/RUNTIME_PROFILE.yaml','runtime_profile_schema':'agent-standard/schemas/RUNTIME_PROFILE.schema.yaml','clone_lineage':'gepetto/CLONE_LINEAGE.yaml','clone_lineage_schema':'agent-standard/schemas/CLONE_LINEAGE.schema.yaml','deployment_profile':'gepetto/DEPLOYMENT_PROFILE.yaml','deployment_profile_schema':'gepetto/schemas/DEPLOYMENT_PROFILE.schema.yaml','standard_approval':'gepetto/bootstrap/STANDARD_APPROVAL.yaml','standard_approval_schema':'agent-standard/schemas/STANDARD_APPROVAL.schema.yaml','test_contract':'gepetto/contracts/gepetto-tests.yaml','test_contract_schema':'gepetto/schemas/TEST_GENERATION_CONTRACT.schema.yaml','validation_contract':'gepetto/contracts/gepetto-validation.yaml','validation_contract_schema':'gepetto/schemas/VALIDATION_SCRIPT_CONTRACT.schema.yaml','test_template':'gepetto/templates/test-template.yaml','script_template':'gepetto/templates/validation-script-template.yaml','runtime':'gepetto/runtime/BOOTSTRAP_RUNTIME.yaml','runtime_schema':'gepetto/runtime/BOOTSTRAP_RUNTIME.schema.yaml'}
    return {'request_id':'r','execution_id':'e','idempotency_key':idem,'operation':'materialize-agent','standard_id':'AGENT_CLONING_STANDARD','standard_version':'1.0.0','spec_id':spec,'spec_version':'1.0.1','context_contract_id':'gepetto-context','context_contract_version':'1.0.0','runtime_profile_id':'gepetto-runtime','runtime_profile_version':'1.0.1','authorization_mode':'SBM_ADMIN_MANUAL_ZIP_DELIVERY','source':{'source_type':'QA','source_id':'fixture','source_version':'1.0.0'},'output_target':str(tmp_path/'out'),'test_contract_id':'gepetto-tests','test_contract_version':'1.0.0','validation_contract_id':'gepetto-validation','validation_contract_version':'1.0.0','test_template_id':'pytest-closed-template','test_template_version':'1.0.0','script_template_id':'python-validation-template','script_template_version':'1.0.0','references':refs,'artifacts':[{'path':'HELLO.txt','source_path':'HELLO.txt'}]}
def test_materialize_and_idempotency_conflict(tmp_path):
    src=tmp_path/'src'; src.mkdir(); (src/'HELLO.txt').write_text('hello')
    req=request(tmp_path); rp=tmp_path/'request.json'; rp.write_text(json.dumps(req))
    result=materialize(rp,agent_root()/'schemas/MATERIALIZATION_REQUEST.schema.yaml',bundle_root(),src,tmp_path/'state'); assert result['execution_status']=='SUCCEEDED'
    result2=materialize(rp,agent_root()/'schemas/MATERIALIZATION_REQUEST.schema.yaml',bundle_root(),src,tmp_path/'state'); assert result2==result
    bad=request(tmp_path,spec='other'); bad['output_target']=str(tmp_path/'out2'); rp.write_text(json.dumps(bad))
    with pytest.raises(Blocked): materialize(rp,agent_root()/'schemas/MATERIALIZATION_REQUEST.schema.yaml',bundle_root(),src,tmp_path/'state')
