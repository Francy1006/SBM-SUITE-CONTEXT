from gepetto.validator import validate_package
from pathlib import Path

def test_package_valid(): assert validate_package(Path(__file__).parents[2])==[]
