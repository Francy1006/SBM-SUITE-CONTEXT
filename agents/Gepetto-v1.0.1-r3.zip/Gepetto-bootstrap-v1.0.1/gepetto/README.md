# Gepetto v1.0.1
Gepetto materializes SBM agents from explicit, versioned contracts. The initial deployment target is a ChatGPT Business Custom GPT. The GPT is a deployment representation, never the canonical source of truth.

Manual bootstrap authorization: a ZIP manually delivered by sbm-admin is sufficient for this initial phase. API authority is intentionally pending and does not block manual bootstrap.
