# QA fixtures
Fixtures are generated in isolated temporary directories by the automated tests. No runtime cache, bytecode, or generated fixture output is part of the final package.
