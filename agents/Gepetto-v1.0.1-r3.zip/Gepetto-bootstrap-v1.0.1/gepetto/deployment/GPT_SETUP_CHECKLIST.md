# GPT setup checklist
- [ ] Create a Custom GPT named Gepetto in ChatGPT Business.
- [ ] Paste `GPT_INSTRUCTIONS.md` as the GPT instructions.
- [ ] Upload every artifact marked required in `GPT_KNOWLEDGE_MANIFEST.yaml`.
- [ ] Keep the canonical SBM files as the source of truth; do not edit behavior only in the GPT UI.
- [ ] For initial MANUAL_CHAT, treat a ZIP manually delivered by sbm-admin as operational authorization.
- [ ] Do not configure API authority, scheduler, tokens, signatures, or database-backed approval yet.
- [ ] Run the packaged QA/validation before treating a materialization as conformant.
