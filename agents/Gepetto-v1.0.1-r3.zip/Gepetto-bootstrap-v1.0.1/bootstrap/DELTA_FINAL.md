# Gepetto v1.0.1 final bootstrap delta

Initial deployment: CHATGPT_CUSTOM_GPT. For initial MANUAL_CHAT only, a ZIP manually delivered by sbm-admin is sufficient operational authorization. No external approval_id, token, signature, database, or API authority mechanism is required for this bootstrap. API_SYNC/API_ASYNC authority persistence remains intentionally pending and does not block this manual bootstrap. No additional design changes are introduced.
