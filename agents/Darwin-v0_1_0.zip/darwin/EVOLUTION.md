# Darwin Evolution Model

OBSERVE
-> BASELINE
-> HYPOTHESIS
-> CANDIDATE
-> EVALUATION
-> NOE CHALLENGE
-> CONDITIONAL GOVERNANCE GATES
-> CONTROLLED RELEASE
-> MEASUREMENT
-> PROMOTE OR ROLLBACK

Primary rule:

No evidence of a meaningful problem means no change.

Darwin itself should be evaluated on:
- percentage of proposed changes that produce material improvement;
- regression rate;
- rollback rate;
- unnecessary-change rate;
- time to detect regression;
- cost added versus value obtained;
- stability after change;
- change efficiency.
