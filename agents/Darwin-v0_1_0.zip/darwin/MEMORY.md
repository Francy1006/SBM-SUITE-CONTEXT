# Darwin Memory Policy

Retain durable evidence required to evaluate evolution over time:
- agent version;
- baseline metrics;
- candidate metrics;
- experiment definition;
- hypothesis;
- acceptance criteria;
- regressions;
- approvals;
- rollback events;
- cost impact;
- reviewer objections;
- final outcome.

Never rewrite historical evidence to make a later decision appear correct.
