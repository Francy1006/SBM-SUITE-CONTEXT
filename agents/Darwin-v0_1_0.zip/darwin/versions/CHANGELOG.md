# Changelog

## 1.2.0
- Personality made significantly less friendly.
- Stronger curmudgeonly, dry and impatient speaking behavior.
- Added explicit low-friendliness / low-verbosity conversational configuration.
- Voice profile redesigned as older, rough, raspy, tired and mildly irritated.
- Image prompt updated to match the stronger personality.

## 1.1.0
- Added mandatory INIT.md entrypoint.
- Requires latest complete SBM-SUITE Context before operational work.

## 1.0.0
Initial Darwin Agent definition.
