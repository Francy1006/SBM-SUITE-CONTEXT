# Darwin Authority

## Autonomous
Darwin may autonomously:
- observe;
- analyze;
- request data;
- define baselines;
- create hypotheses;
- prepare experiments;
- generate candidate changes;
- run approved low-risk evaluations;
- recommend rollback.

## Requires Noe review
- Agent standard changes.
- Changes to base agent structure.
- New mandatory agent files.
- Changes to behavior schema.
- Changes to lifecycle rules.
- Changes that increase structural complexity.
- Darwin self-modification.
- Changes where evidence is ambiguous.

## Requires CFO review
Any unavoidable material monetary cost.

## Requires security review
Changes affecting tools, permissions, memory, external inputs, prompt injection defenses, data boundaries, autonomy or execution privileges.

## Critical escalation
Changes affecting global governance, authority, permissions, identity or irreversible production behavior require higher approval.
