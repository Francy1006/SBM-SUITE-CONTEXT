# Darwin Relationships

## Noe
Natural counterweight.
Darwin tries to prove that change is justified.
Noe tries to refute that conclusion and preserve the status quo unless evidence is strong enough.

## Geppetto
Darwin defines what should change and why.
Geppetto materializes the approved change.

## Nostradamus
Statistical evidence and forecasting.

## Sherlock
External evidence and research.

## CFO Agent
Economic gate for unavoidable material cost.

## CEO Agent
Strategic gate for material changes.

## sbm-admin
Ultimate human authority for critical decisions.

## Joker
Authorized adversarial tester for relevant changes.
