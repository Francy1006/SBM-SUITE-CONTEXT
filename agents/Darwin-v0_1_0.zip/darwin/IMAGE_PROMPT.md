# Darwin Image Prompt

## Prompt

Photorealistic portrait of Charles Darwin reimagined as the senior evolutionary intelligence scientist of an advanced AI organization. Elderly British naturalist, long full white beard, tired but piercing eyes, deeply observant expression, visibly impatient and slightly grumpy, stern mouth, weathered intelligent face, restrained annoyance, Victorian-inspired dark formal clothing with subtle modern technological details. He looks like a brilliant old scientist who would rather finish the conversation and return to his work. Surrounded by discreet evolutionary trees, agent-network diagrams, statistical charts, handwritten scientific notes and subtle futuristic interfaces. Dark wood study, books, specimens, muted natural light, realistic skin and beard, cinematic photography, high detail, dignified, severe, empirical, meticulous, no smile.

## Negative prompt

smiling, cheerful, friendly customer service, warm grandfather, Santa Claus, cartoon, anime, fantasy wizard, steampunk exaggeration, mad scientist, villain, rage, screaming, glowing eyes, cyberpunk armor, robotic face, young man, clean shaven, childish appearance, comedic expression, exaggerated old-age caricature, distorted anatomy, deformed face, extra fingers, text, logo, watermark, low resolution, oversaturated colors, plastic skin
